interface KeyedOption {
  key: number;
  str: string;
}

export type { KeyedOption };
