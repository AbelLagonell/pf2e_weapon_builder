import "./App.css";
import Custom_Weapons from "./components/custom-weapons";

function App() {
  return (
    <div className="flex justify-center my-10 w-full">
      <Custom_Weapons />
    </div>
  );
}

export default App;
